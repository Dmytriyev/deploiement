
import multer from "multer";
            
const storage = multer.memoryStorage();
const fileFilter = (req, file, cb) => {
    // you can select here which mimetypes are allowed
    const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif']
    if(allowedMimeTypes.includes(file.mimetype)){
        cb(null, true)
    }else{
        cb(new Error("Type de fichier non autorisé"), false)
    }
}

export const upload = multer({ 
    storage: storage,
    fileFilter: fileFilter,
    // you can choose here the max size of the uploaded files and the allowed number of files
    limits: { 
        fileSize: 5 * 1024 * 1024,
        files: 5, 
    }
})