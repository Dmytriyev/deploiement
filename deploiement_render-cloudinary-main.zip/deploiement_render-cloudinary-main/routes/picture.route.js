
import { Router } from "express";
import { createPicture, getAllPictures, getPicturesByMembreId, deletePicture } from "../controllers/picture.controller.js"
import { upload } from "../middlewares/multer.js"


const router = Router()

router.post('/new', upload.single('image'), createPicture)
router.get('/all', getAllPictures)
router.get('/:id', getPicturesByMembreId)
router.delete('/:id', deletePicture)

export default router