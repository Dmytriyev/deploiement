
import { Router } from "express";
import { createPost, getAllPosts, getPostById, updatePost, deletePost } from "../controllers/post.controller.js"
import { upload } from "../middlewares/multer.js";

const router = Router()

router.post('/new', upload.single('image'), createPost)
router.get('/all', getAllPosts)
router.get('/:id', getPostById)
router.put('/:id', upload.single('image'), updatePost)
router.delete('/:id', deletePost)

export default router