Ce projet intègre le téléversement d'images vers Cloudinary, une plateforme de stockage d'images en ligne. Vous aurez donc besoin de créer un compte sur cette plateforme (vous pouvez créer un compte à partir de votre compte Github)

## Paramètres
Vous aurez alors besoin d'installer les dépendances :
- `multer`
- `cloudinary`
- `streamifier`

Pour ce projet, dans `.env`, on a besoin de 
- `PORT`

à voir dans la partie "clusters" de <i>MongoDB/Atlas</i>
- `MONGO_URI`

à voir dans les paramètres "API keys" de <i>Cloudinary</i>>
- `CLOUDINARY_CLOUD_NAME`
- `CLOUDINARY_API_KEY`
- `CLOUDINARY_API_SECRET`

Au final on obtient :
```env
PORT=3000
MONGO_URI=mongodb+srv://xxxxx:xxxxx@cluster0.xxxxx.mongodb.net/nom_bdd
CLOUDINARY_CLOUD_NAME=xxxxx
CLOUDINARY_API_KEY=xxxxx
CLOUDINARY_API_SECRET=xxxxx
```

## Particularités
Les différences avec un projet Node/Multer classique :
- le `storage` dans le middleware `multer.js`
- ajout de l'utilitaire `/utils/cloudinary.js` qui va gérer les échanges avec la plateforme `Cloudinary`
- les variables d'environnement nécessaires à `Cloudinary`
- les propriétés nécessaires dans les models `post` et `picture`
- les validations JOI modifiées en fonction des models
- le traitement des images dans les controllers (`createPost`, `updatePost`, `deletePost`, `createPicture`, `deletePicture`)

## Déploiement
Nous avons vu les étapes nécessaires pour déployer ce site sur render :
- création d'un `web service` sur <i>Render.com</i> et association de ce server au repo voulu sur <i>Github</i>
- création d'un script, propre à la production,  dans `package.json` :
```json
    "start": "node server.js"
```
- mise en place des variables d'environnement
- déploiement...

Si vous modifier votre travail en local et faites un push, `render` qui est "branché" sur votre repo, le saura et redéploiera automatiquement votre site avec les modifications.