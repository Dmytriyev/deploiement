import mongoose from 'mongoose';

const postSchema = new mongoose.Schema({
    titre: {
      type: String
    },
    contenu: {
      type: String
    },
    image: {
      public_id: {
          type: String,
          default: null
        },
      url: {
        type: String,
        default: null
      }
    }

}, { timestamps: true });

export default mongoose.model('Post', postSchema);
