import mongoose from 'mongoose';

const pictureSchema = new mongoose.Schema({
    image: {
      type: String,
      required: true,
    },
    imagePublicId: {
      type: String,
    },
    alt: {
      type: String,
      required: true
    },
}, { timestamps: true });

export default mongoose.model('Picture', pictureSchema);
