import joi from "joi";
import mongoose from "mongoose";

export default function pictureValidation(body){
    const pictureCreate = joi.object({
      image: joi.string().uri().required(),
      imagePublicId: joi.string().optional(),
      alt: joi.string().required(),
    })

    return {
        pictureCreate: pictureCreate.validate(body),
    }
}
