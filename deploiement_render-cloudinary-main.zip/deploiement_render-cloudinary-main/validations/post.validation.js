import joi from "joi";

export default function postValidation(body){
    const cloudinaryImageSchema = joi.object({
      public_id: joi.string().allow(null),
      url: joi.string().uri().allow(null)
    }).allow(null);

    const postCreate = joi.object({
      titre: joi.string(),
      contenu: joi.string(),
      image: cloudinaryImageSchema,
    })

    const postUpdate = joi.object({
      titre: joi.string(),
      contenu: joi.string(),
      image: cloudinaryImageSchema,
    })

    return {
        postCreate: postCreate.validate(body),
        postUpdate: postUpdate.validate(body),
    }
}
